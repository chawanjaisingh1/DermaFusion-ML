"""Train the EfficientNetB0 feature plus soft-voting ensemble.

Expected dataset layout:
    dataset/
        class_a/*.jpg
        class_b/*.jpg

Run from the project root after installing requirements.txt:
    python classifier/train_model.py --dataset data/skin_images
"""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.applications.efficientnet import preprocess_input
from tensorflow.keras.utils import image_dataset_from_directory


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('classifier/ml_models'))
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--seed', type=int, default=42)
    return parser.parse_args()


def extract_features(dataset_path, batch_size):
    dataset = image_dataset_from_directory(
        dataset_path,
        image_size=(224, 224),
        batch_size=batch_size,
        shuffle=False,
        label_mode='int',
    )
    extractor = EfficientNetB0(include_top=False, weights='imagenet', pooling='avg')
    features = []
    labels = []
    for images, batch_labels in dataset:
        features.append(extractor(preprocess_input(images), training=False).numpy())
        labels.append(batch_labels.numpy())
    return extractor, np.concatenate(features), np.concatenate(labels), dataset.class_names


def main():
    args = parse_args()
    if not args.dataset.is_dir():
        raise SystemExit(f'Dataset directory does not exist: {args.dataset}')

    try:
        from imblearn.over_sampling import SMOTE
    except ImportError as error:
        raise SystemExit('Install imbalanced-learn before training: pip install imbalanced-learn') from error

    extractor, features, labels, class_names = extract_features(args.dataset, args.batch_size)
    train_features, test_features, train_labels, test_labels = train_test_split(
        features,
        labels,
        test_size=0.2,
        random_state=args.seed,
        stratify=labels,
    )
    balanced_features, balanced_labels = SMOTE(random_state=args.seed).fit_resample(
        train_features, train_labels
    )

    svm_search = GridSearchCV(
        SVC(probability=True, class_weight='balanced', random_state=args.seed),
        {'C': [1, 10], 'gamma': ['scale', 'auto']},
        cv=3,
        n_jobs=-1,
    )
    svm_search.fit(balanced_features, balanced_labels)

    ensemble = VotingClassifier(
        estimators=[
            ('svm', svm_search.best_estimator_),
            ('rf', RandomForestClassifier(n_estimators=300, class_weight='balanced', random_state=args.seed, n_jobs=-1)),
            ('lda', LinearDiscriminantAnalysis()),
            ('nb', GaussianNB()),
        ],
        voting='soft',
    )
    ensemble.fit(balanced_features, balanced_labels)

    args.output.mkdir(parents=True, exist_ok=True)
    extractor.save(args.output / 'efficientnetb0_feature_extractor.keras')
    joblib.dump(ensemble, args.output / 'ensemble.joblib')

    metadata = {
        'model_version': f'ensemble-efficientnetb0-{datetime.now(timezone.utc).date().isoformat()}',
        'classes': class_names,
        'feature_dimensions': int(features.shape[1]),
        'input_size': [224, 224],
        'training_samples': int(len(train_labels)),
        'balanced_training_samples': int(len(balanced_labels)),
        'test_samples': int(len(test_labels)),
        'training_accuracy': round(float(accuracy_score(balanced_labels, ensemble.predict(balanced_features))), 4),
        'test_accuracy': round(float(accuracy_score(test_labels, ensemble.predict(test_features))), 4),
        'random_seed': args.seed,
        'classifiers': ['SVM', 'Random Forest', 'LDA', 'Naive Bayes'],
        'created_at': datetime.now(timezone.utc).isoformat(),
    }
    with (args.output / 'training_metadata.json').open('w', encoding='utf-8') as metadata_file:
        json.dump(metadata, metadata_file, indent=2)
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
