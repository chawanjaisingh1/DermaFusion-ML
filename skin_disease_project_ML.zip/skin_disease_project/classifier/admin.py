from django.contrib import admin

from .models import UploadedImage


@admin.register(UploadedImage)
class UploadedImageAdmin(admin.ModelAdmin):
	list_display = ('predicted_class', 'confidence', 'created_at')
	list_filter = ('predicted_class', 'created_at')
	search_fields = ('predicted_class',)
