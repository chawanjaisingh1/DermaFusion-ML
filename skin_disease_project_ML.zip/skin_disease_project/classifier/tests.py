from io import BytesIO
from tempfile import TemporaryDirectory

from django.core.files.uploadedfile import SimpleUploadedFile
from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from PIL import Image

from .models import UploadedImage
from .views import get_prediction_details


class ClassifierViewsTests(TestCase):
	def test_public_pages_render(self):
		for path in ('/', '/upload/', '/result/', '/about/', '/history/', '/login/', '/register/'):
			with self.subTest(path=path):
				response = self.client.get(path)

				self.assertEqual(response.status_code, 200)

	def test_prediction_uses_image_name(self):
		self.assertEqual(get_prediction_details('eczema_sample.jpg'), ('Eczema', 91.3))
		self.assertEqual(get_prediction_details('unknown-image.jpg'), ('Healthy Skin', 96.2))

	def test_upload_creates_result(self):
		image_buffer = BytesIO()
		Image.new('RGB', (10, 10), 'red').save(image_buffer, format='JPEG')
		image = SimpleUploadedFile(
			'eczema_sample.jpg',
			image_buffer.getvalue(),
			content_type='image/jpeg',
		)

		with TemporaryDirectory() as media_root, override_settings(MEDIA_ROOT=media_root):
			response = self.client.post('/upload/', {'image': image})

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Eczema')
		self.assertEqual(UploadedImage.objects.count(), 1)
		self.assertEqual(UploadedImage.objects.get().predicted_class, 'Eczema')

	def test_invalid_upload_is_rejected(self):
		image = SimpleUploadedFile(
			'notes.txt', b'not-an-image', content_type='text/plain'
		)

		response = self.client.post('/upload/', {'image': image})

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Only JPG and PNG images are supported.')
		self.assertEqual(UploadedImage.objects.count(), 0)

	def test_history_contains_saved_records(self):
		UploadedImage.objects.create(
			image='uploads/example.jpg', predicted_class='Acne', confidence=88.7
		)

		response = self.client.get('/history/')

		self.assertContains(response, 'Acne')
		self.assertContains(response, '88.70% confidence')

	def test_login_and_logout(self):
		User.objects.create_user(username='demo', password='correct-password')

		response = self.client.post(
			'/login/', {'username': 'demo', 'password': 'correct-password'}
		)

		self.assertRedirects(response, '/')
		self.assertTrue(response.wsgi_request.user.is_authenticated)
		self.assertRedirects(self.client.get('/logout/'), '/')

	def test_registration_creates_and_logs_in_user(self):
		response = self.client.post('/register/', {
			'username': 'new-user',
			'email': 'new@example.com',
			'password1': 'Strong-password-123',
			'password2': 'Strong-password-123',
		})

		self.assertRedirects(response, '/')
		self.assertTrue(response.wsgi_request.user.is_authenticated)
		self.assertTrue(User.objects.filter(username='new-user').exists())

	def test_registration_rejects_duplicate_username(self):
		User.objects.create_user(username='existing', password='correct-password')

		response = self.client.post('/register/', {
			'username': 'existing',
			'email': 'new@example.com',
			'password1': 'Strong-password-123',
			'password2': 'Strong-password-123',
		})

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'A user with that username already exists.')
