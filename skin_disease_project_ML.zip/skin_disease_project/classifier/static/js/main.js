const imageInput = document.getElementById("imageInput");
const imagePreview = document.getElementById("imagePreview");
const previewContainer = document.getElementById("previewContainer");
const fileName = document.getElementById("fileName");
const dropZone = document.getElementById("dropZone");

const revealTargets = document.querySelectorAll(
    ".hero-content, .hero-card, .section-heading, .feature-card, .tech-grid > div, " +
    ".upload-header, .upload-container, .warning-box, .result-header, .result-container, " +
    ".auth-card, .history-item, .empty-state"
);

if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const revealObserver = new IntersectionObserver(function (entries, observer) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add("is-visible");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: "0px 0px -32px 0px" });

    revealTargets.forEach(function (element, index) {
        element.classList.add("reveal");
        element.style.setProperty("--reveal-delay", `${Math.min(index % 4, 3) * 80}ms`);
        revealObserver.observe(element);
    });

    document.documentElement.classList.add("motion-ready");
}

function showSelectedImage(file) {
    if (!file || !file.type.startsWith("image/")) {
        return false;
    }

    fileName.textContent = file.name;
    const reader = new FileReader();
    reader.onload = function (event) {
        imagePreview.src = event.target.result;
        previewContainer.style.display = "block";
        previewContainer.classList.remove("is-visible");
        void previewContainer.offsetWidth;
        previewContainer.classList.add("is-visible");
    };
    reader.readAsDataURL(file);
    return true;
}

if (imageInput) {
    imageInput.addEventListener("change", function () {
        const file = this.files[0];

        if (!file) {
            return;
        }

        if (!file.type.startsWith("image/")) {
            alert("Please select a valid image.");
            this.value = "";
            return;
        }

        showSelectedImage(file);
    });
}

if (dropZone) {
    ["dragenter", "dragover"].forEach(function (eventName) {
        dropZone.addEventListener(eventName, function (event) {
            event.preventDefault();
            dropZone.classList.add("is-dragging");
        });
    });

    ["dragleave", "drop"].forEach(function (eventName) {
        dropZone.addEventListener(eventName, function (event) {
            event.preventDefault();
            dropZone.classList.remove("is-dragging");
        });
    });

    dropZone.addEventListener("drop", function (event) {
        const file = event.dataTransfer.files[0];
        if (file && showSelectedImage(file)) {
            imageInput.files = event.dataTransfer.files;
        } else if (file) {
            alert("Please select a valid image.");
        }
    });
}
