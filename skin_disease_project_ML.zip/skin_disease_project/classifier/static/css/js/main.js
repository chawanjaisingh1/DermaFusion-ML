```javascript
const imageInput = document.getElementById("imageInput");
const imagePreview = document.getElementById("imagePreview");
const previewContainer = document.getElementById("previewContainer");
const fileName = document.getElementById("fileName");

if (imageInput) {

    imageInput.addEventListener("change", function () {

        const file = this.files[0];

        if (!file) {
            return;
        }

        if (!file.type.startsWith("image/")) {

            alert("Please select a valid image.");

            this.value = "";

            return;
        }

        fileName.textContent = file.name;

        const reader = new FileReader();

        reader.onload = function (event) {

            imagePreview.src = event.target.result;

            previewContainer.style.display = "block";

        };

        reader.readAsDataURL(file);

    });

}
```
