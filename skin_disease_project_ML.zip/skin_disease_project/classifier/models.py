from django.db import models


class UploadedImage(models.Model):
    image = models.ImageField(upload_to='uploads/')
    predicted_class = models.CharField(max_length=100, default='Healthy Skin')
    confidence = models.FloatField(default=0.0)
    top_predictions = models.JSONField(default=list)
    model_version = models.CharField(max_length=100, default='demo-filename-heuristic')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.predicted_class} - {self.created_at.date()}"
