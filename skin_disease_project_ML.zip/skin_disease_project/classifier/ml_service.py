import json
from functools import lru_cache
from pathlib import Path

import numpy as np
from django.conf import settings


DEFAULT_CLASSES = [
    'Actinic keratosis',
    'Basal cell carcinoma',
    'Benign keratosis',
    'Dermatofibroma',
    'Melanoma',
    'Melanocytic nevus',
    'Vascular lesion',
    'Healthy skin',
]


def _model_directory():
    return Path(getattr(settings, 'ML_MODEL_DIR', settings.BASE_DIR / 'classifier' / 'ml_models'))


def _metadata_path():
    return Path(settings.BASE_DIR) / 'classifier' / 'data' / 'diseases.json'


@lru_cache(maxsize=1)
def get_disease_metadata():
    try:
        with _metadata_path().open(encoding='utf-8') as metadata_file:
            return json.load(metadata_file)
    except (OSError, json.JSONDecodeError):
        return {name: {'description': 'No additional information is available.'} for name in DEFAULT_CLASSES}


@lru_cache(maxsize=1)
def _load_artifacts():
    model_directory = _model_directory()
    extractor_path = model_directory / 'efficientnetb0_feature_extractor.keras'
    ensemble_path = model_directory / 'ensemble.joblib'
    metadata_path = model_directory / 'training_metadata.json'

    if not extractor_path.exists() or not ensemble_path.exists():
        return None

    import joblib
    from tensorflow.keras.models import load_model

    extractor = load_model(extractor_path, compile=False)
    ensemble = joblib.load(ensemble_path)
    training_metadata = {}
    if metadata_path.exists():
        with metadata_path.open(encoding='utf-8') as metadata_file:
            training_metadata = json.load(metadata_file)
    return extractor, ensemble, training_metadata


def _demo_prediction(file_name):
    name = (file_name or '').lower()
    rules = (
        (('melanoma', 'cancer', 'tumor', 'lesion'), 'Melanoma', 0.948),
        (('eczema', 'dermatitis', 'rash', 'itch'), 'Eczema', 0.913),
        (('psoriasis', 'scaly', 'plaque'), 'Psoriasis', 0.895),
        (('acne', 'pimple', 'blackhead'), 'Acne', 0.887),
    )
    for keywords, label, probability in rules:
        if any(keyword in name for keyword in keywords):
            return label, probability
    return 'Healthy skin', 0.962


def _top_predictions(labels, probabilities, limit=3):
    scores = zip(labels, probabilities)
    return [
        {'label': label, 'probability': round(float(probability) * 100, 2)}
        for label, probability in sorted(scores, key=lambda item: item[1], reverse=True)[:limit]
    ]


def predict_image(image_path, file_name):
    artifacts = None if image_path is None else _load_artifacts()
    if artifacts is None:
        label, probability = _demo_prediction(file_name)
        return {
            'label': label,
            'confidence': round(probability * 100, 2),
            'top_predictions': [{'label': label, 'probability': round(probability * 100, 2)}],
            'model_version': 'demo-filename-heuristic',
            'mode': 'demo',
        }

    extractor, ensemble, training_metadata = artifacts
    from tensorflow.keras.applications.efficientnet import preprocess_input
    from tensorflow.keras.utils import img_to_array, load_img

    image = load_img(image_path, target_size=(224, 224))
    image_array = preprocess_input(np.expand_dims(img_to_array(image), axis=0))
    features = extractor.predict(image_array, verbose=0)
    probabilities = ensemble.predict_proba(features)[0]
    labels = training_metadata.get('classes', DEFAULT_CLASSES)
    predictions = _top_predictions(labels, probabilities)
    return {
        'label': predictions[0]['label'],
        'confidence': predictions[0]['probability'],
        'top_predictions': predictions,
        'model_version': training_metadata.get('model_version', 'efficientnetb0-ensemble'),
        'mode': 'ensemble',
    }