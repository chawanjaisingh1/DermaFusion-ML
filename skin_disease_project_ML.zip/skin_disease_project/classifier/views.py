from pathlib import Path
from uuid import uuid4

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect, render
from PIL import Image, UnidentifiedImageError

from .ml_service import get_disease_metadata, predict_image
from .forms import RegistrationForm
from .models import UploadedImage


def get_prediction_details(image_name):
    """Keep the original helper available for existing integrations and tests."""
    prediction = predict_image(None, image_name)
    label = prediction['label'].replace('Healthy skin', 'Healthy Skin')
    return label, prediction['confidence']


def home(request):
    return render(request, 'home.html')


def upload(request):
    if request.method == 'POST':
        uploaded_image = request.FILES.get('image')
        if not uploaded_image:
            messages.error(request, 'Please choose an image to analyze.')
            return render(request, 'upload.html')

        if uploaded_image.content_type not in {'image/jpeg', 'image/png'}:
            messages.error(request, 'Only JPG and PNG images are supported.')
            return render(request, 'upload.html')

        if uploaded_image.size > 10 * 1024 * 1024:
            messages.error(request, 'Please choose an image smaller than 10 MB.')
            return render(request, 'upload.html')

        try:
            image = Image.open(uploaded_image)
            image.verify()
            uploaded_image.seek(0)
        except (OSError, UnidentifiedImageError):
            messages.error(request, 'The selected file is not a valid image.')
            return render(request, 'upload.html')

        media_dir = Path(settings.MEDIA_ROOT) / 'uploads'
        media_dir.mkdir(parents=True, exist_ok=True)

        extension = Path(uploaded_image.name).suffix.lower()
        file_name = f'{uuid4().hex}{extension}'
        file_path = media_dir / file_name

        with open(file_path, 'wb+') as destination:
            for chunk in uploaded_image.chunks():
                destination.write(chunk)

        prediction = predict_image(file_path, uploaded_image.name)

        record = UploadedImage.objects.create(
            image=f"uploads/{file_name}",
            predicted_class=prediction['label'],
            confidence=prediction['confidence'],
            top_predictions=prediction['top_predictions'],
            model_version=prediction['model_version'],
        )

        return render(
            request,
            'result.html',
            {
                'image_url': record.image.url,
                'disease': record.predicted_class,
                'confidence': record.confidence,
                'top_predictions': record.top_predictions,
                'model_version': record.model_version,
                'metadata': get_disease_metadata().get(record.predicted_class, {}),
            },
        )

    return render(request, 'upload.html')


def result(request):
    latest = UploadedImage.objects.order_by('-created_at').first()
    if latest:
        return render(
            request,
            'result.html',
            {
                'image_url': latest.image.url,
                'disease': latest.predicted_class,
                'confidence': latest.confidence,
                'top_predictions': latest.top_predictions,
                'model_version': latest.model_version,
                'metadata': get_disease_metadata().get(latest.predicted_class, {}),
            },
        )

    return render(
        request,
        'result.html',
        {
            'image_url': '',
            'disease': 'Healthy Skin',
            'confidence': 96.0,
            'top_predictions': [],
            'model_version': 'demo-filename-heuristic',
            'metadata': {},
        },
    )


def about(request):
    return render(request, 'about.html')


def history(request):
    records = UploadedImage.objects.order_by('-created_at')
    return render(request, 'history.html', {'records': records})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.get_username()}.')
            return redirect('home')

        messages.error(request, 'The username or password is incorrect.')

    return render(request, 'login.html')


def register_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    form = RegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, 'Your account has been created successfully.')
        return redirect('home')

    return render(request, 'register.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.success(request, 'You have been signed out.')
    return redirect('home')
